#include <vector>
#include <string>
#include <memory>
#include "edge.h"
#include "vertex.h"

#include <iostream>
using std::cout;

Edge::Edge(int number, std::string display) : edgeNumber{number}, owner{nullptr}, display{display} {}

void Edge::addAdjEdges(Edge *e) {
    adjEdges.emplace_back(e);
}

void Edge::addAdjVertices(Vertex *v) {
    adjVertices.emplace_back(v);
    v->addAdjEdges(this);
}

std::string Edge::getDisplay() {
    return display;
}

void Edge::printInfo() {
        int el = adjEdges.size();

        for (int i = 0; i < el; ++i) {
                cout << adjEdges[i]->getEdgeNumber() << " ";
        }
        cout << "/";

        int vl = adjVertices.size();

        for (int i = 0; i < vl; ++i) {
                cout << adjVertices[i]->getVertexNumber() << " ";
        }
}

int Edge::getEdgeNumber() {
        return edgeNumber;
}
