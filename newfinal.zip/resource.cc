#include <string>
#include "resource.h"

std::string Resource::toStr(int type) {
    if (type == 0) {
        return "BRICK";
    } else if (type == 1) {
        return "ENERGY";
    } else if (type == 2) {
        return "GLASS";
    } else if (type == 3) {
        return "HEAT";
    } else if (type == 4) {
        return "WIFI";
    } else if (type == 5) {
        return "PARK";
    }
}
