#include <string>
#include <vector>
#include <memory>
#include "edge.h"
#include "vertex.h"

#include <iostream>
using std::cout;

Vertex::Vertex(int number, std::string display) : vertexNumber{number}, owner{nullptr}, display{display} {}

void Vertex::addAdjEdges(Edge *e) {
    adjEdges.emplace_back(e);
}

void Vertex::notify(Subject&) {

}

void Vertex::addAdjVertices(Vertex *v) {
    adjVertices.emplace_back(v);
}

std::string Vertex::getDisplay() {
    return display;
}

std::string Vertex::getName() {
    return display;
}

void Vertex::printInfo() {
	int el = adjEdges.size();

	for (int i = 0; i < el; ++i) {
		cout << adjEdges[i]->getEdgeNumber() << " ";
	}
	cout << "/";

	int vl = adjVertices.size();

	for (int i = 0; i < vl; ++i) {
                cout << adjVertices[i]->getVertexNumber() << " ";
        }
}

int Vertex::getVertexNumber() {
	return vertexNumber;
}
