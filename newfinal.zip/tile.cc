#include <memory>
#include <string>
#include "tile.h"

Tile::Tile(int number, int resource, int value)
    : tileNumber{number}, resource{resource}, tileValue{value}, geese{false} {}

int Tile::getResource() {
    return resource;
}

int Tile::getTileValue() {
    return tileValue;
}

std::shared_ptr<Player> Tile::findPlayer(std::string colour) {
    std::shared_ptr<Player> n = std::make_shared<Player>();
    return n;
}
