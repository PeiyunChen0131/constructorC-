#ifndef _BOARD_H_
#define _BOARD_H_
#include <memory>
#include <vector>
#include <string>
#include "tile.h"
#include "edge.h"
#include "vertex.h"
#include "player.h"

class Board {
	protected:
	std::vector<std::shared_ptr<Tile>> theTiles;
    	std::vector<std::shared_ptr<Edge>> theEdges;
    	std::vector<std::shared_ptr<Vertex>> theVertices;
    	std::vector<std::shared_ptr<Player>> thePlayer;
    	int howManyPlayer = 4;
	int geeseIsAt;

	public:
	void printTopEdge(int *vertice, int *edge);

	void printBoard();

	void initBoard();

	virtual void createBoard(int seed, std::string fname) = 0;
};

#endif
