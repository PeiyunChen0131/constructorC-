#include <iostream>
#include <memory>
#include <string>
#include "board.h"
#include "layoutboard.h"
using std::string;
using std::istream;
using std::ifstream;
using std::istringstream;

int main( int argc, char * argv[] ) {
    const string SEED_ARG = "-seed";
    const string LOAD_ARG = "-load";
    const string BOARD_ARG = "-board";
    const string RANDOM_ARG = "-random-board";
    
    //istringstream iss = std::make_shared<istringstream>(argv[1]);
    //string fname;
    //iss >> fname;
    //std::shared_ptr<istream> in = std::make_shared<ifstream>(fname);

    std::shared_ptr<Board> theBoard = std::make_shared<LayoutBoard>();
    theBoard->createBoard(1, argv[1]);
    theBoard->printBoard();
    return 0;
}
