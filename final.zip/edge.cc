#include <vector>
#include <string>
#include <memory>
#include "edge.h"
#include "vertex.h"

Edge::Edge(int number, std::string display) : edgeNumber{number}, owner{nullptr}, display{display} {}

void Edge::addAdjEdges(Edge *e) {
    adjEdges.emplace_back(e);
}

void Edge::addAdjVertices(Vertex *v) {
    adjVertices.emplace_back(v);
    v->addAdjEdges(this);
}

std::string Edge::getDisplay() {
    return display;
}
