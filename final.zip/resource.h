#ifndef _RESOURCE_H_
#define _RESOURCE_H_
#include <string>
#include <vector>

class Resource {
    std::vector<int> vecOfResource;

    public:
    std::string toStr(int type);
};

#endif
