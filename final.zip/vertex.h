#ifndef _VERTEX_H_
#define _VERTEX_H_
#include <memory>
#include <string>
#include <vector>
#include "observer.h"
#include "edge.h"
#include "player.h"

class Edge;

class Vertex : public Observer {
    int vertexNumber;
    std::shared_ptr<Player> owner;
    std::string display;
    std::vector<Edge *> adjEdges;
    std::vector<Vertex *> adjVertices;

    public:
    Vertex(int number, std::string display);

    void notify(Subject&) override;

    void addAdjEdges(Edge *e);

    void addAdjVertices(Vertex *v);

    std::string getDisplay();
};

#endif
