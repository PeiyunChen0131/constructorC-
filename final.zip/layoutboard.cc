#include <memory>
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include "layoutboard.h"
#include "edge.h"
#include "tile.h"
#include "vertex.h"
#include "subject.h"
using std::to_string;
using std::ifstream;
using std::istream;

void LayoutBoard::createBoard(int seed, std::string fname) {
    std::string str;
        for (int i = 0; i < 54; ++i) {
            str = to_string(i);
            if (i < 10) {
                str.insert(0, " ");
            }
            theVertices.emplace_back(std::make_shared<Vertex>(i, str));
        }

        for (int i = 0; i < 72; ++i) {
            str = to_string(i);
            if (i < 10) {
                str.insert(0, " ");
            }
            theEdges.emplace_back(std::make_shared<Edge>(i, str));
        }

        // connecting vertices with vertices
        theVertices[0]->addAdjVertices(theVertices[1].get());
        theVertices[0]->addAdjVertices(theVertices[3].get());
        theVertices[1]->addAdjVertices(theVertices[0].get());
        theVertices[1]->addAdjVertices(theVertices[4].get());
        theVertices[2]->addAdjVertices(theVertices[3].get());
        theVertices[2]->addAdjVertices(theVertices[7].get());
        theVertices[3]->addAdjVertices(theVertices[0].get());
        theVertices[3]->addAdjVertices(theVertices[2].get());
        theVertices[3]->addAdjVertices(theVertices[8].get());
        theVertices[4]->addAdjVertices(theVertices[1].get());
        theVertices[4]->addAdjVertices(theVertices[5].get());
        theVertices[4]->addAdjVertices(theVertices[9].get());
        theVertices[5]->addAdjVertices(theVertices[4].get());
        theVertices[5]->addAdjVertices(theVertices[10].get());
        theVertices[6]->addAdjVertices(theVertices[7].get());
        theVertices[6]->addAdjVertices(theVertices[12].get());
        theVertices[7]->addAdjVertices(theVertices[2].get());
        theVertices[7]->addAdjVertices(theVertices[6].get());
        theVertices[7]->addAdjVertices(theVertices[13].get());
        theVertices[8]->addAdjVertices(theVertices[3].get());
        theVertices[8]->addAdjVertices(theVertices[9].get());
        theVertices[8]->addAdjVertices(theVertices[14].get());
        theVertices[9]->addAdjVertices(theVertices[4].get());
        theVertices[9]->addAdjVertices(theVertices[8].get());
        theVertices[9]->addAdjVertices(theVertices[15].get());
        theVertices[10]->addAdjVertices(theVertices[5].get());
        theVertices[10]->addAdjVertices(theVertices[11].get());
        theVertices[10]->addAdjVertices(theVertices[16].get());
        theVertices[11]->addAdjVertices(theVertices[10].get());
        theVertices[11]->addAdjVertices(theVertices[17].get());
        for (int i = 12; i < 42; ++i) {
            theVertices[i]->addAdjVertices(theVertices[i-6].get());
            theVertices[i]->addAdjVertices(theVertices[i+6].get());
        }
        theVertices[13]->addAdjVertices(theVertices[14].get());
        theVertices[14]->addAdjVertices(theVertices[13].get());
        theVertices[15]->addAdjVertices(theVertices[16].get());
        theVertices[16]->addAdjVertices(theVertices[15].get());
        theVertices[18]->addAdjVertices(theVertices[19].get());
        theVertices[19]->addAdjVertices(theVertices[18].get());
        theVertices[20]->addAdjVertices(theVertices[21].get());
        theVertices[21]->addAdjVertices(theVertices[20].get());
        theVertices[22]->addAdjVertices(theVertices[23].get());
        theVertices[23]->addAdjVertices(theVertices[22].get());
        theVertices[25]->addAdjVertices(theVertices[26].get());
        theVertices[26]->addAdjVertices(theVertices[25].get());
        theVertices[27]->addAdjVertices(theVertices[28].get());
        theVertices[28]->addAdjVertices(theVertices[27].get());
        theVertices[30]->addAdjVertices(theVertices[31].get());
        theVertices[31]->addAdjVertices(theVertices[30].get());
        theVertices[32]->addAdjVertices(theVertices[33].get());
        theVertices[33]->addAdjVertices(theVertices[32].get());
        theVertices[34]->addAdjVertices(theVertices[35].get());
        theVertices[35]->addAdjVertices(theVertices[34].get());
        theVertices[37]->addAdjVertices(theVertices[38].get());
        theVertices[38]->addAdjVertices(theVertices[37].get());
        theVertices[39]->addAdjVertices(theVertices[40].get());
        theVertices[40]->addAdjVertices(theVertices[39].get());
        for (int i = 42; i < 48; ++i) {
            theVertices[i]->addAdjVertices(theVertices[i-6].get());
            if (i % 2 == 0) {
                theVertices[i]->addAdjVertices(theVertices[i+1].get());
                theVertices[i+1]->addAdjVertices(theVertices[i].get());
            }
        }
        for (int i = 48; i < 52; ++i) {
            theVertices[i]->addAdjVertices(theVertices[i-5].get());
            theVertices[i-5]->addAdjVertices(theVertices[i].get());
            if (i % 2 == 0) {
                theVertices[i]->addAdjVertices(theVertices[i+1].get());
                theVertices[i+1]->addAdjVertices(theVertices[i].get());
            }
        }
        theVertices[49]->addAdjVertices(theVertices[52].get());
        theVertices[52]->addAdjVertices(theVertices[49].get());
        theVertices[50]->addAdjVertices(theVertices[53].get());
        theVertices[53]->addAdjVertices(theVertices[50].get());
        theVertices[52]->addAdjVertices(theVertices[53].get());
        theVertices[53]->addAdjVertices(theVertices[52].get());

        // connecting vertices with edges
        theEdges[0]->addAdjVertices(theVertices[0].get());
        theEdges[0]->addAdjVertices(theVertices[1].get());
        theEdges[1]->addAdjVertices(theVertices[0].get());
        theEdges[1]->addAdjVertices(theVertices[3].get());
        theEdges[2]->addAdjVertices(theVertices[1].get());
        theEdges[2]->addAdjVertices(theVertices[4].get());
        theEdges[3]->addAdjVertices(theVertices[2].get());
        theEdges[3]->addAdjVertices(theVertices[3].get());
        theEdges[4]->addAdjVertices(theVertices[4].get());
        theEdges[4]->addAdjVertices(theVertices[5].get());
        for (int i = 5; i < 9; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-3].get());
            theEdges[i]->addAdjVertices(theVertices[i+2].get());
        }
        theEdges[9]->addAdjVertices(theVertices[6].get());
        theEdges[9]->addAdjVertices(theVertices[7].get());
        theEdges[10]->addAdjVertices(theVertices[8].get());
        theEdges[10]->addAdjVertices(theVertices[9].get());
        theEdges[11]->addAdjVertices(theVertices[10].get());
        theEdges[11]->addAdjVertices(theVertices[11].get());
        for (int i = 12; i < 18; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-6].get());
            theEdges[i]->addAdjVertices(theVertices[i].get());
        }
        theEdges[18]->addAdjVertices(theVertices[13].get());
        theEdges[18]->addAdjVertices(theVertices[14].get());
        theEdges[19]->addAdjVertices(theVertices[15].get());
        theEdges[19]->addAdjVertices(theVertices[16].get());
        for (int i = 20; i < 26; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-8].get());
            theEdges[i]->addAdjVertices(theVertices[i-2].get());
        }
        theEdges[26]->addAdjVertices(theVertices[18].get());
        theEdges[26]->addAdjVertices(theVertices[19].get());
        theEdges[27]->addAdjVertices(theVertices[20].get());
        theEdges[27]->addAdjVertices(theVertices[21].get());
        theEdges[28]->addAdjVertices(theVertices[22].get());
        theEdges[28]->addAdjVertices(theVertices[23].get());
        for (int i = 29; i < 35; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-11].get());
            theEdges[i]->addAdjVertices(theVertices[i-5].get());
        }
        theEdges[35]->addAdjVertices(theVertices[25].get());
        theEdges[35]->addAdjVertices(theVertices[26].get());
        theEdges[36]->addAdjVertices(theVertices[27].get());
        theEdges[36]->addAdjVertices(theVertices[28].get());
        for (int i = 37; i < 43; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-13].get());
            theEdges[i]->addAdjVertices(theVertices[i-7].get());
        }
        theEdges[43]->addAdjVertices(theVertices[30].get());
        theEdges[43]->addAdjVertices(theVertices[31].get());
        theEdges[44]->addAdjVertices(theVertices[32].get());
        theEdges[44]->addAdjVertices(theVertices[33].get());
        theEdges[45]->addAdjVertices(theVertices[34].get());
        theEdges[45]->addAdjVertices(theVertices[35].get());
        for (int i = 46; i < 52; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-16].get());
            theEdges[i]->addAdjVertices(theVertices[i-10].get());
        }
        theEdges[52]->addAdjVertices(theVertices[37].get());
        theEdges[52]->addAdjVertices(theVertices[38].get());
        theEdges[53]->addAdjVertices(theVertices[39].get());
        theEdges[53]->addAdjVertices(theVertices[40].get());
        for (int i = 54; i < 60; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-18].get());
            theEdges[i]->addAdjVertices(theVertices[i-12].get());
        }
        theEdges[60]->addAdjVertices(theVertices[42].get());
        theEdges[60]->addAdjVertices(theVertices[43].get());
        theEdges[61]->addAdjVertices(theVertices[44].get());
        theEdges[61]->addAdjVertices(theVertices[45].get());
        theEdges[62]->addAdjVertices(theVertices[46].get());
        theEdges[62]->addAdjVertices(theVertices[47].get());
        for (int i = 63; i < 67; ++i) {
            theEdges[i]->addAdjVertices(theVertices[i-20].get());
            theEdges[i]->addAdjVertices(theVertices[i-15].get());
        }
        theEdges[67]->addAdjVertices(theVertices[48].get());
        theEdges[67]->addAdjVertices(theVertices[49].get());
        theEdges[68]->addAdjVertices(theVertices[50].get());
        theEdges[68]->addAdjVertices(theVertices[51].get());
        theEdges[69]->addAdjVertices(theVertices[49].get());
        theEdges[69]->addAdjVertices(theVertices[52].get());
        theEdges[70]->addAdjVertices(theVertices[50].get());
        theEdges[70]->addAdjVertices(theVertices[53].get());
        theEdges[71]->addAdjVertices(theVertices[52].get());
        theEdges[71]->addAdjVertices(theVertices[53].get());

        // connecting edges with edges
        theEdges[0]->addAdjEdges(theEdges[1].get());
        theEdges[0]->addAdjEdges(theEdges[2].get());
        theEdges[1]->addAdjEdges(theEdges[0].get());
        theEdges[1]->addAdjEdges(theEdges[3].get());
        theEdges[1]->addAdjEdges(theEdges[6].get());
        theEdges[2]->addAdjEdges(theEdges[0].get());
        theEdges[2]->addAdjEdges(theEdges[4].get());
        theEdges[2]->addAdjEdges(theEdges[7].get());
        theEdges[3]->addAdjEdges(theEdges[1].get());
        theEdges[3]->addAdjEdges(theEdges[5].get());
        theEdges[3]->addAdjEdges(theEdges[6].get());
        theEdges[4]->addAdjEdges(theEdges[2].get());
        theEdges[4]->addAdjEdges(theEdges[7].get());
        theEdges[4]->addAdjEdges(theEdges[8].get());
        theEdges[5]->addAdjEdges(theEdges[3].get());
        theEdges[5]->addAdjEdges(theEdges[9].get());
        theEdges[5]->addAdjEdges(theEdges[13].get());
        theEdges[6]->addAdjEdges(theEdges[1].get());
        theEdges[6]->addAdjEdges(theEdges[3].get());
        theEdges[6]->addAdjEdges(theEdges[10].get());
        theEdges[6]->addAdjEdges(theEdges[14].get());
        theEdges[7]->addAdjEdges(theEdges[2].get());
        theEdges[7]->addAdjEdges(theEdges[4].get());
        theEdges[7]->addAdjEdges(theEdges[10].get());
        theEdges[7]->addAdjEdges(theEdges[15].get());
        theEdges[8]->addAdjEdges(theEdges[4].get());
        theEdges[8]->addAdjEdges(theEdges[11].get());
        theEdges[8]->addAdjEdges(theEdges[16].get());
        theEdges[9]->addAdjEdges(theEdges[5].get());
        theEdges[9]->addAdjEdges(theEdges[12].get());
        theEdges[9]->addAdjEdges(theEdges[13].get());
        theEdges[10]->addAdjEdges(theEdges[6].get());
        theEdges[10]->addAdjEdges(theEdges[7].get());
        theEdges[10]->addAdjEdges(theEdges[14].get());
        theEdges[10]->addAdjEdges(theEdges[15].get());
        theEdges[11]->addAdjEdges(theEdges[8].get());
        theEdges[11]->addAdjEdges(theEdges[16].get());
        theEdges[11]->addAdjEdges(theEdges[17].get());
        theEdges[12]->addAdjEdges(theEdges[9].get());
        theEdges[12]->addAdjEdges(theEdges[20].get());
        theEdges[13]->addAdjEdges(theEdges[5].get());
        theEdges[13]->addAdjEdges(theEdges[9].get());
        theEdges[13]->addAdjEdges(theEdges[18].get());
        theEdges[13]->addAdjEdges(theEdges[21].get());
        theEdges[14]->addAdjEdges(theEdges[6].get());
        theEdges[14]->addAdjEdges(theEdges[10].get());
        theEdges[14]->addAdjEdges(theEdges[18].get());
        theEdges[14]->addAdjEdges(theEdges[22].get());
        theEdges[15]->addAdjEdges(theEdges[7].get());
        theEdges[15]->addAdjEdges(theEdges[10].get());
        theEdges[15]->addAdjEdges(theEdges[19].get());
        theEdges[15]->addAdjEdges(theEdges[23].get());
        theEdges[16]->addAdjEdges(theEdges[8].get());
        theEdges[16]->addAdjEdges(theEdges[11].get());
        theEdges[16]->addAdjEdges(theEdges[19].get());
        theEdges[16]->addAdjEdges(theEdges[24].get());
        theEdges[17]->addAdjEdges(theEdges[11].get());
        theEdges[17]->addAdjEdges(theEdges[25].get());
        theEdges[18]->addAdjEdges(theEdges[13].get());
        theEdges[18]->addAdjEdges(theEdges[14].get());
        theEdges[18]->addAdjEdges(theEdges[21].get());
        theEdges[18]->addAdjEdges(theEdges[22].get());
        theEdges[19]->addAdjEdges(theEdges[15].get());
        theEdges[19]->addAdjEdges(theEdges[16].get());
        theEdges[19]->addAdjEdges(theEdges[23].get());
        theEdges[19]->addAdjEdges(theEdges[24].get());
        theEdges[20]->addAdjEdges(theEdges[12].get());
        theEdges[20]->addAdjEdges(theEdges[26].get());
        theEdges[20]->addAdjEdges(theEdges[29].get());
        theEdges[21]->addAdjEdges(theEdges[13].get());
        theEdges[21]->addAdjEdges(theEdges[18].get());
        theEdges[21]->addAdjEdges(theEdges[26].get());
        theEdges[21]->addAdjEdges(theEdges[30].get());
        theEdges[22]->addAdjEdges(theEdges[14].get());
        theEdges[22]->addAdjEdges(theEdges[18].get());
        theEdges[22]->addAdjEdges(theEdges[27].get());
        theEdges[22]->addAdjEdges(theEdges[31].get());
        theEdges[23]->addAdjEdges(theEdges[15].get());
        theEdges[23]->addAdjEdges(theEdges[19].get());
        theEdges[23]->addAdjEdges(theEdges[27].get());
        theEdges[23]->addAdjEdges(theEdges[32].get());
        theEdges[24]->addAdjEdges(theEdges[16].get());
        theEdges[24]->addAdjEdges(theEdges[19].get());
        theEdges[24]->addAdjEdges(theEdges[33].get());
        theEdges[24]->addAdjEdges(theEdges[28].get());
        theEdges[25]->addAdjEdges(theEdges[17].get());
        theEdges[25]->addAdjEdges(theEdges[34].get());
        theEdges[25]->addAdjEdges(theEdges[28].get());
        theEdges[26]->addAdjEdges(theEdges[20].get());
        theEdges[26]->addAdjEdges(theEdges[21].get());
        theEdges[26]->addAdjEdges(theEdges[39].get());
        theEdges[26]->addAdjEdges(theEdges[30].get());
        theEdges[27]->addAdjEdges(theEdges[22].get());
        theEdges[27]->addAdjEdges(theEdges[23].get());
        theEdges[27]->addAdjEdges(theEdges[31].get());
        theEdges[27]->addAdjEdges(theEdges[32].get());
        theEdges[28]->addAdjEdges(theEdges[24].get());
        theEdges[28]->addAdjEdges(theEdges[25].get());
        theEdges[28]->addAdjEdges(theEdges[33].get());
        theEdges[28]->addAdjEdges(theEdges[34].get());
        theEdges[29]->addAdjEdges(theEdges[20].get());
        theEdges[29]->addAdjEdges(theEdges[26].get());
        theEdges[29]->addAdjEdges(theEdges[37].get());
        theEdges[30]->addAdjEdges(theEdges[21].get());
        theEdges[30]->addAdjEdges(theEdges[26].get());
        theEdges[30]->addAdjEdges(theEdges[38].get());
        theEdges[30]->addAdjEdges(theEdges[35].get());
        theEdges[31]->addAdjEdges(theEdges[22].get());
        theEdges[31]->addAdjEdges(theEdges[27].get());
        theEdges[31]->addAdjEdges(theEdges[32].get());
        theEdges[31]->addAdjEdges(theEdges[39].get());
        theEdges[32]->addAdjEdges(theEdges[23].get());
        theEdges[32]->addAdjEdges(theEdges[27].get());
        theEdges[32]->addAdjEdges(theEdges[36].get());
        theEdges[32]->addAdjEdges(theEdges[40].get());
        theEdges[33]->addAdjEdges(theEdges[24].get());
        theEdges[33]->addAdjEdges(theEdges[28].get());
        theEdges[33]->addAdjEdges(theEdges[36].get());
        theEdges[33]->addAdjEdges(theEdges[41].get());
        theEdges[34]->addAdjEdges(theEdges[25].get());
        theEdges[34]->addAdjEdges(theEdges[28].get());
        theEdges[34]->addAdjEdges(theEdges[42].get());
        theEdges[35]->addAdjEdges(theEdges[30].get());
        theEdges[35]->addAdjEdges(theEdges[31].get());
        theEdges[35]->addAdjEdges(theEdges[38].get());
        theEdges[35]->addAdjEdges(theEdges[39].get());
        theEdges[36]->addAdjEdges(theEdges[32].get());
        theEdges[36]->addAdjEdges(theEdges[33].get());
        theEdges[36]->addAdjEdges(theEdges[40].get());
        theEdges[36]->addAdjEdges(theEdges[41].get());
        theEdges[37]->addAdjEdges(theEdges[29].get());
        theEdges[37]->addAdjEdges(theEdges[43].get());
        theEdges[37]->addAdjEdges(theEdges[46].get());
        theEdges[38]->addAdjEdges(theEdges[30].get());
        theEdges[38]->addAdjEdges(theEdges[35].get());
        theEdges[38]->addAdjEdges(theEdges[43].get());
        theEdges[38]->addAdjEdges(theEdges[47].get());
        theEdges[39]->addAdjEdges(theEdges[31].get());
        theEdges[39]->addAdjEdges(theEdges[35].get());
        theEdges[39]->addAdjEdges(theEdges[44].get());
        theEdges[39]->addAdjEdges(theEdges[48].get());
        theEdges[40]->addAdjEdges(theEdges[32].get());
        theEdges[40]->addAdjEdges(theEdges[44].get());
        theEdges[40]->addAdjEdges(theEdges[49].get());
        theEdges[41]->addAdjEdges(theEdges[33].get());
        theEdges[41]->addAdjEdges(theEdges[36].get());
        theEdges[41]->addAdjEdges(theEdges[41].get());
        theEdges[41]->addAdjEdges(theEdges[45].get());
        theEdges[42]->addAdjEdges(theEdges[34].get());
        theEdges[42]->addAdjEdges(theEdges[45].get());
        theEdges[42]->addAdjEdges(theEdges[51].get());
        theEdges[43]->addAdjEdges(theEdges[37].get());
        theEdges[43]->addAdjEdges(theEdges[38].get());
        theEdges[43]->addAdjEdges(theEdges[46].get());
        theEdges[43]->addAdjEdges(theEdges[47].get());
        theEdges[44]->addAdjEdges(theEdges[39].get());
        theEdges[44]->addAdjEdges(theEdges[40].get());
        theEdges[44]->addAdjEdges(theEdges[48].get());
        theEdges[44]->addAdjEdges(theEdges[49].get());
        theEdges[45]->addAdjEdges(theEdges[41].get());
        theEdges[45]->addAdjEdges(theEdges[42].get());
        theEdges[45]->addAdjEdges(theEdges[50].get());
        theEdges[45]->addAdjEdges(theEdges[51].get());
        theEdges[46]->addAdjEdges(theEdges[37].get());
        theEdges[46]->addAdjEdges(theEdges[43].get());
        theEdges[46]->addAdjEdges(theEdges[54].get());
        theEdges[47]->addAdjEdges(theEdges[38].get());
        theEdges[47]->addAdjEdges(theEdges[43].get());
        theEdges[47]->addAdjEdges(theEdges[52].get());
        theEdges[47]->addAdjEdges(theEdges[55].get());
        theEdges[48]->addAdjEdges(theEdges[39].get());
        theEdges[48]->addAdjEdges(theEdges[44].get());
        theEdges[48]->addAdjEdges(theEdges[52].get());
        theEdges[48]->addAdjEdges(theEdges[56].get());
        theEdges[49]->addAdjEdges(theEdges[40].get());
        theEdges[49]->addAdjEdges(theEdges[44].get());
        theEdges[49]->addAdjEdges(theEdges[53].get());
        theEdges[49]->addAdjEdges(theEdges[57].get());
        theEdges[50]->addAdjEdges(theEdges[41].get());
        theEdges[50]->addAdjEdges(theEdges[45].get());
        theEdges[50]->addAdjEdges(theEdges[50].get());
        theEdges[50]->addAdjEdges(theEdges[53].get());
        theEdges[51]->addAdjEdges(theEdges[42].get());
        theEdges[51]->addAdjEdges(theEdges[45].get());
        theEdges[51]->addAdjEdges(theEdges[59].get());
        theEdges[52]->addAdjEdges(theEdges[47].get());
        theEdges[52]->addAdjEdges(theEdges[48].get());
        theEdges[52]->addAdjEdges(theEdges[55].get());
        theEdges[52]->addAdjEdges(theEdges[56].get());
        theEdges[53]->addAdjEdges(theEdges[49].get());
        theEdges[53]->addAdjEdges(theEdges[50].get());
        theEdges[53]->addAdjEdges(theEdges[57].get());
        theEdges[53]->addAdjEdges(theEdges[58].get());
        theEdges[54]->addAdjEdges(theEdges[46].get());
        theEdges[54]->addAdjEdges(theEdges[60].get());
        theEdges[55]->addAdjEdges(theEdges[47].get());
        theEdges[55]->addAdjEdges(theEdges[52].get());
        theEdges[55]->addAdjEdges(theEdges[60].get());
        theEdges[55]->addAdjEdges(theEdges[63].get());
        theEdges[56]->addAdjEdges(theEdges[48].get());
        theEdges[56]->addAdjEdges(theEdges[52].get());
        theEdges[56]->addAdjEdges(theEdges[61].get());
        theEdges[56]->addAdjEdges(theEdges[64].get());
        theEdges[57]->addAdjEdges(theEdges[49].get());
        theEdges[57]->addAdjEdges(theEdges[53].get());
        theEdges[57]->addAdjEdges(theEdges[61].get());
        theEdges[57]->addAdjEdges(theEdges[65].get());
        theEdges[58]->addAdjEdges(theEdges[50].get());
        theEdges[58]->addAdjEdges(theEdges[53].get());
        theEdges[58]->addAdjEdges(theEdges[62].get());
        theEdges[58]->addAdjEdges(theEdges[66].get());
        theEdges[59]->addAdjEdges(theEdges[51].get());
        theEdges[59]->addAdjEdges(theEdges[62].get());
        theEdges[60]->addAdjEdges(theEdges[54].get());
        theEdges[60]->addAdjEdges(theEdges[55].get());
        theEdges[60]->addAdjEdges(theEdges[63].get());
        theEdges[61]->addAdjEdges(theEdges[56].get());
        theEdges[61]->addAdjEdges(theEdges[57].get());
        theEdges[61]->addAdjEdges(theEdges[64].get());
        theEdges[61]->addAdjEdges(theEdges[65].get());
        theEdges[62]->addAdjEdges(theEdges[58].get());
        theEdges[62]->addAdjEdges(theEdges[59].get());
        theEdges[62]->addAdjEdges(theEdges[66].get());
        theEdges[63]->addAdjEdges(theEdges[55].get());
        theEdges[63]->addAdjEdges(theEdges[60].get());
        theEdges[63]->addAdjEdges(theEdges[67].get());
        theEdges[64]->addAdjEdges(theEdges[56].get());
        theEdges[64]->addAdjEdges(theEdges[61].get());
        theEdges[64]->addAdjEdges(theEdges[67].get());
        theEdges[64]->addAdjEdges(theEdges[69].get());
        theEdges[65]->addAdjEdges(theEdges[57].get());
        theEdges[65]->addAdjEdges(theEdges[61].get());
        theEdges[65]->addAdjEdges(theEdges[68].get());
        theEdges[65]->addAdjEdges(theEdges[70].get());
        theEdges[66]->addAdjEdges(theEdges[58].get());
        theEdges[66]->addAdjEdges(theEdges[62].get());
        theEdges[66]->addAdjEdges(theEdges[68].get());
        theEdges[67]->addAdjEdges(theEdges[63].get());
        theEdges[67]->addAdjEdges(theEdges[64].get());
        theEdges[67]->addAdjEdges(theEdges[69].get());
        theEdges[68]->addAdjEdges(theEdges[65].get());
        theEdges[68]->addAdjEdges(theEdges[66].get());
        theEdges[68]->addAdjEdges(theEdges[70].get());
        theEdges[69]->addAdjEdges(theEdges[64].get());
        theEdges[69]->addAdjEdges(theEdges[67].get());
        theEdges[69]->addAdjEdges(theEdges[71].get());
        theEdges[70]->addAdjEdges(theEdges[65].get());
        theEdges[70]->addAdjEdges(theEdges[68].get());
        theEdges[70]->addAdjEdges(theEdges[71].get());
        theEdges[71]->addAdjEdges(theEdges[69].get());
        theEdges[71]->addAdjEdges(theEdges[70].get());

        std::string input;
        int resourceNum;
        int tileValue;

	std::shared_ptr<istream> in = std::make_shared<ifstream>( fname );

        for (int i = 0; i < 19; ++i) {
            *in >> input;
            resourceNum = std::stoi(input, nullptr);
            *in >> input;
            tileValue = std::stoi(input, nullptr);
            
            std::shared_ptr<Tile> tile = std::make_shared<Tile>(i, resourceNum, tileValue);
            //tile.addAdjEdges();
            if (i == 0) {
                tile->attach(theVertices[0]);
                tile->attach(theVertices[1]);
                tile->attach(theVertices[3]);
                tile->attach(theVertices[4]);
                tile->attach(theVertices[8]);
                tile->attach(theVertices[9]);
            } else if (i == 1) {
                tile->attach(theVertices[2]);
                tile->attach(theVertices[3]);
                tile->attach(theVertices[7]);
                tile->attach(theVertices[8]);
                tile->attach(theVertices[13]);
                tile->attach(theVertices[14]);
            } else if (i == 2) {
                tile->attach(theVertices[4]);
                tile->attach(theVertices[5]);
                tile->attach(theVertices[9]);
                tile->attach(theVertices[10]);
                tile->attach(theVertices[15]);
                tile->attach(theVertices[16]);
            } else if (i == 3) {
                tile->attach(theVertices[6]);
                tile->attach(theVertices[7]);
                tile->attach(theVertices[12]);
                tile->attach(theVertices[13]);
                tile->attach(theVertices[18]);
                tile->attach(theVertices[19]);
            } else if (i == 4) {
                tile->attach(theVertices[8]);
                tile->attach(theVertices[9]);
                tile->attach(theVertices[14]);
                tile->attach(theVertices[15]);
                tile->attach(theVertices[20]);
                tile->attach(theVertices[21]);
            } else if (i == 5) {
                tile->attach(theVertices[10]);
                tile->attach(theVertices[11]);
                tile->attach(theVertices[16]);
                tile->attach(theVertices[17]);
                tile->attach(theVertices[22]);
                tile->attach(theVertices[23]);
            } else if (i == 6) {
                tile->attach(theVertices[13]);
                tile->attach(theVertices[14]);
                tile->attach(theVertices[19]);
                tile->attach(theVertices[20]);
                tile->attach(theVertices[25]);
                tile->attach(theVertices[26]);
            } else if (i == 7) {
                tile->attach(theVertices[15]);
                tile->attach(theVertices[16]);
                tile->attach(theVertices[21]);
                tile->attach(theVertices[22]);
                tile->attach(theVertices[27]);
                tile->attach(theVertices[28]);
            } else if (i == 8) {
                tile->attach(theVertices[18]);
                tile->attach(theVertices[19]);
                tile->attach(theVertices[24]);
                tile->attach(theVertices[25]);
                tile->attach(theVertices[30]);
                tile->attach(theVertices[31]);
            } else if (i == 9) {
                tile->attach(theVertices[20]);
                tile->attach(theVertices[21]);
                tile->attach(theVertices[26]);
                tile->attach(theVertices[27]);
                tile->attach(theVertices[32]);
                tile->attach(theVertices[33]);
            } else if (i == 10) {
                tile->attach(theVertices[22]);
                tile->attach(theVertices[23]);
                tile->attach(theVertices[28]);
                tile->attach(theVertices[29]);
                tile->attach(theVertices[34]);
                tile->attach(theVertices[35]);
            } else if (i == 11) {
                tile->attach(theVertices[25]);
                tile->attach(theVertices[26]);
                tile->attach(theVertices[31]);
                tile->attach(theVertices[32]);
                tile->attach(theVertices[37]);
                tile->attach(theVertices[38]);
            } else if (i == 12) {
                tile->attach(theVertices[27]);
                tile->attach(theVertices[28]);
                tile->attach(theVertices[33]);
                tile->attach(theVertices[34]);
                tile->attach(theVertices[39]);
                tile->attach(theVertices[40]);
            } else if (i == 13) {
                tile->attach(theVertices[30]);
                tile->attach(theVertices[31]);
                tile->attach(theVertices[36]);
                tile->attach(theVertices[37]);
                tile->attach(theVertices[42]);
                tile->attach(theVertices[43]);
            } else if (i == 14) {
                tile->attach(theVertices[32]);
                tile->attach(theVertices[33]);
                tile->attach(theVertices[38]);
                tile->attach(theVertices[39]);
                tile->attach(theVertices[44]);
                tile->attach(theVertices[45]);
            } else if (i == 15) {
                tile->attach(theVertices[34]);
                tile->attach(theVertices[35]);
                tile->attach(theVertices[40]);
                tile->attach(theVertices[41]);
                tile->attach(theVertices[46]);
                tile->attach(theVertices[47]);
            } else if (i == 16) {
                tile->attach(theVertices[37]);
                tile->attach(theVertices[38]);
                tile->attach(theVertices[43]);
                tile->attach(theVertices[44]);
                tile->attach(theVertices[48]);
                tile->attach(theVertices[49]);
            } else if (i == 17) {
                tile->attach(theVertices[39]);
                tile->attach(theVertices[40]);
                tile->attach(theVertices[45]);
                tile->attach(theVertices[46]);
                tile->attach(theVertices[50]);
                tile->attach(theVertices[51]);
            } else if (i == 18) {
                tile->attach(theVertices[44]);
                tile->attach(theVertices[45]);
                tile->attach(theVertices[49]);
                tile->attach(theVertices[50]);
                tile->attach(theVertices[52]);
                tile->attach(theVertices[53]);
            }
            theTiles.emplace_back(tile);
        }
}
