#include <iostream>
#include <string>
#include <memory>
#include "board.h"
#include "resource.h"
using std::cout;
using std::endl;

void printIntSp(int num) {
    if (num < 10) {
        cout << " ";
    }
    cout << num;
}

void printResource(int num) {
	Resource r;
	cout << "  ";
	if (num == 1) {
		cout << r.toStr(num);
	} else if (num == 0 || num == 2) {
		cout << r.toStr(num) << " ";
	} else {
		cout << r.toStr(num) << "  ";
	}
}

void Board::printTopEdge(int *vertice, int *edge) {
    const std::string doubMins = "--";
    const std::string verBar = "|";

    cout << verBar;
    cout << theVertices[*vertice]->getDisplay();
    (*vertice)++;
    cout << verBar << doubMins;
    cout << theEdges[*edge]->getDisplay();
    cout << doubMins << verBar;
    cout << theVertices[*vertice]->getDisplay();
    cout << verBar;
}

void Board::printBoard() {
    const std::string fl = "                    ";
    const std::string sl = "          ";
    const std::string fEmp = "                      |         |                     ";
    //const std::string sEmp = "            |         |         |         |           ";
    //const std::string tEmp = "  |         |         |         |         |         | ";
    const std::string tileCap = "        ";
    const std::string tileCapW = " |         |";
    const std::string verBar = "|";

    int curTile = 0;
    int curVertice = 0;
    int curEdge = 0;

    //std::vector<std::vector<std::string>> row;
    for (int i = 1; i < 42; ++i) {
        //std::vector<std::string> c;
        cout << "      ";
        if (i == 1 || i == 41) {
            //c.emplace_back(fl);
            cout << fl;
            printTopEdge(&curVertice, &curEdge);
            cout << fl;
            curVertice++;
            curEdge++;
        } else if (i == 2 || i == 40) {
            cout << fEmp;
        } else if (i == 3) {
            cout << fl << " ";
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << "   ";
            printIntSp(curTile);
            cout << "   ";
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << " " << fl;
        } else if (i == 4) {
            cout << fl << "  |";
            printResource(theTiles[curTile]->getResource());
            cout << " | " << fl;
        } else if (i == 5 || i == 37) {
            cout << sl;
            printTopEdge(&curVertice, &curEdge);
            curVertice++;
            curEdge++;
            cout << "  ";
            if (theTiles[curTile]->getTileValue() == 7) {
                cout << "  ";
            } else {
                printIntSp(theTiles[curTile]->getTileValue());
            }
            cout << "  ";
            printTopEdge(&curVertice, &curEdge);
            curVertice++;
            curEdge++;
            cout << sl;
        } else if (i == 6) {
            if (curTile == geeseIsAt) {
                cout << "            |         |  GEESE  |         |           ";
            } else {
                cout << "            |         |         |         |           ";
            }
        } else if (i == 7) {
            cout << sl << " ";
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << "   ";
            printIntSp(curTile);
            cout << "   ";
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << tileCap;
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << "   ";
            printIntSp(curTile + 1);
            cout << "   ";
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << " " << sl;
        } else if (i == 8) {
            cout << "            |";
            printResource(theTiles[curTile]->getResource());
            cout << tileCapW;
            printResource(theTiles[curTile+1]->getResource());
            cout << " |           ";
        } else if (i == 9 || i == 17 || i == 25 || i == 33) {
            for (int x = 0; x < 2; ++x) {
                printTopEdge(&curVertice, &curEdge);
                curVertice++;
                curEdge++;
                cout << "  ";
                if (theTiles[curTile+x]->getTileValue() == 7) {
                    cout << "  ";
                } else {
                    printIntSp(theTiles[curTile+x]->getTileValue());
                }
                cout << "  ";
            }
            printTopEdge(&curVertice, &curEdge);
            curVertice++;
            curEdge++;
            cout << "  ";
        } else if (i == 10 || i == 18 || i == 26) {
            if (curTile == geeseIsAt) {
                cout << "  |         |  GEESE  |         |         |         | ";
            } else if ((curTile + 1) == geeseIsAt) {
                cout << "  |         |         |         |  GEESE  |         | ";
            } else {
                cout << "  |         |         |         |         |         | ";
            }
        } else if (i == 11 || i == 19 || i == 27) {
            cout << " ";
            for (int x = 0; x < 3; ++x) {
                cout << theEdges[curEdge]->getDisplay();
                curEdge++;
                cout << "   ";
                printIntSp(curTile+x);
                cout << "   ";
                cout << theEdges[curEdge]->getDisplay();
                curEdge++;
                if (x < 2) {
                    cout << tileCap;
                }
            }
            cout << " ";
        }  else if (i == 12 || i == 20 || i == 28) {
            cout << "  |";
            for (int x = 0; x < 3; ++x) {
                printResource(theTiles[curTile+x]->getResource());
                if (x < 2) {
                    cout << tileCapW;
                }
            }
            cout << " | ";
        } else if (i == 13 || i == 21 || i ==29) {
            cout << "|" << theVertices[curVertice]->getDisplay() << "|";
            curVertice++;
            for (int x = 0; x < 3; ++x) {
                cout << "  ";
                if (theTiles[curTile+x]->getTileValue() == 7) {
                    cout << "  ";
                } else {
                    printIntSp(theTiles[curTile+x]->getTileValue());
                }
                cout << "  ";
                if (x < 2) {
                    printTopEdge(&curVertice, &curEdge);
                    curVertice++;
                    curEdge++;
                }
            }
            cout << "|" << theVertices[curVertice]->getDisplay() << "|";
            curVertice++;
        } else if (i == 14 || i == 22 || i == 30) {
            if (curTile == geeseIsAt) {
                cout << "  |  GEESE  |         |         |         |         | ";
            } else if ((curTile + 1) == geeseIsAt) {
                cout << "  |         |         |  GEESE  |         |         | ";
            } else if ((curTile + 2) == geeseIsAt) {
                cout << "  |         |         |         |         |  GEESE  | ";
            } else {
                cout << "  |         |         |         |         |         | ";
            }
        } else if (i == 15 || i == 23 || i == 31) {
            cout << " ";
            for (int x = 0; x < 3; ++x) {
                cout << theEdges[curEdge]->getDisplay();
                curEdge++;
                cout << tileCap;
                cout << theEdges[curEdge]->getDisplay();
                curEdge++;
                if (x < 2) {
                    cout << "   ";
                    printIntSp(curTile+x);
                    cout << "   ";
                }
            }
            cout << " ";
        } else if (i == 16 || i == 24 || i == 32) {
            cout << " ";
	    for (int x = 0; x < 3; ++x) {
                cout << tileCapW;
                if (x < 2) {
                    printResource(theTiles[curTile+x]->getResource());
                }
            }
            cout << " ";
        } else if (i == 34) {
            if (curTile == geeseIsAt) {
                cout << "            |  GEESE  |         |         |           ";
            } else if ((curTile + 1) == geeseIsAt) {
                cout << "            |         |         |  GEESE  |           ";
            } else {
                cout << "            |         |         |         |           ";
            }
        } else if (i == 35) {
            cout << "           ";
            for (int x = 0; x < 2; ++x) {
                cout << theEdges[curEdge]->getDisplay();
                curEdge++;
                cout << tileCap;
                cout << theEdges[curEdge]->getDisplay();
                curEdge++;
                if (x < 1) {
                    cout << "   ";
                    printIntSp(curTile+x);
                    cout << "   ";
                }
            }
            cout << "           ";
        } else if (i == 36) {
            cout << "            |         |";
            printResource(theTiles[curTile]->getResource());
            cout << " |         |           ";
        } else if (i == 38) {
            if (curTile == geeseIsAt) {
                cout << "                      |  GEESE  |                     ";
            } else {
                cout << "                      |         |                     ";
            }
        } else if (i == 39) {
            cout << "                     ";
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << "        ";
            cout << theEdges[curEdge]->getDisplay();
            curEdge++;
            cout << "                     ";
        }

        cout << endl;
        if (i % 4 == 2 && i != 2) {
            if (i == 6) {
                curTile++;
            } else if (i == 10 || i == 18 || i == 26 || i == 34) {
                curTile += 2;
            } else {
                curTile += 3;
            }
        }
        //row.emplace_back(c);
    }
    
}
