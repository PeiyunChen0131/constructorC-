#ifndef _TILE_H_
#define _TILE_H_
#include <memory>
#include <string>
#include "subject.h"
#include "player.h"

class Resource;

class Tile : public Subject {
    int tileNumber;
    const int resource;
    int tileValue;
    bool geese;

    public:
    Tile(int number, int resource, int value);

    int getResource();
    int getTileValue();
    //bool haveGeese() { return geese; }
    std::shared_ptr<Player> findPlayer(std::string colour);
};

#endif
