#include <iostream>
#include <string>
#include <memory>
#include "board.h"

class LayoutBoard : public Board {
  public:
    virtual void createBoard(int seed, std::string fname) override;
};
