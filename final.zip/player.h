#ifndef _PLAYER_H_
#define _PLAYER_H_
#include <memory>
#include <string>

class Player{

};

#endif
