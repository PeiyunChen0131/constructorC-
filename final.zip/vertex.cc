#include <string>
#include <vector>
#include <memory>
#include "edge.h"
#include "vertex.h"

Vertex::Vertex(int number, std::string display) : vertexNumber{number}, owner{nullptr}, display{display} {}

void Vertex::addAdjEdges(Edge *e) {
    adjEdges.emplace_back(e);
}

void Vertex::notify(Subject&) {

}

void Vertex::addAdjVertices(Vertex *v) {
    adjVertices.emplace_back(v);
}

std::string Vertex::getDisplay() {
    return display;
}
