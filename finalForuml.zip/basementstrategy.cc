#include "basementstrategy.h"

Resource BasementStrategy::strategyGiveRes(Resource res) {
    return res;
}

std::string BasementStrategy::getName() {
    return name;
}
