#ifndef _DICESTRATEGY_H_
#define _DICESTRATEGY_H_

class DiceStrategy {
    public:
    virtual int rollDice() = 0;
};

#endif
